"""A common analysis grid in local UTM, so every dataset lines up pixel for pixel.

The 10 m grid is snapped to multiples of 30 m, so the Landsat 30 m grid nests
exactly inside it (one 30 m cell = 3 x 3 cells of 10 m).
"""

import math
from dataclasses import dataclass

from affine import Affine
from pyproj import CRS, Transformer


@dataclass
class Grid:
    crs: CRS
    transform: Affine
    width: int
    height: int

    @property
    def res(self):
        return self.transform.a

    @property
    def bounds(self):
        left, top = self.transform.c, self.transform.f
        return left, top - self.height * self.res, left + self.width * self.res, top

    def coarsen(self, factor):
        t = self.transform
        return Grid(
            self.crs,
            Affine(t.a * factor, 0, t.c, 0, t.e * factor, t.f),
            self.width // factor,
            self.height // factor,
        )


def utm_crs_for(lon, lat):
    zone = int((lon + 180) // 6) + 1
    return CRS.from_epsg((32600 if lat >= 0 else 32700) + zone)


def grid_from_bbox(bbox, res=10, snap=30):
    """Build a north-up UTM grid covering a WGS84 bbox [min_lon, min_lat, max_lon, max_lat]."""
    min_lon, min_lat, max_lon, max_lat = bbox
    crs = utm_crs_for((min_lon + max_lon) / 2, (min_lat + max_lat) / 2)
    to_utm = Transformer.from_crs("EPSG:4326", crs, always_xy=True)
    xs, ys = to_utm.transform(
        [min_lon, max_lon, min_lon, max_lon], [min_lat, min_lat, max_lat, max_lat]
    )
    left = math.floor(min(xs) / snap) * snap
    bottom = math.floor(min(ys) / snap) * snap
    right = math.ceil(max(xs) / snap) * snap
    top = math.ceil(max(ys) / snap) * snap
    width = int(round((right - left) / res))
    height = int(round((top - bottom) / res))
    return Grid(crs, Affine(res, 0, left, 0, -res, top), width, height)


def frac_to_xy(grid, fx, fy):
    """Convert fractional site coordinates (0..1, origin south-west) to UTM metres."""
    left, bottom, right, top = grid.bounds
    return left + fx * (right - left), bottom + fy * (top - bottom)

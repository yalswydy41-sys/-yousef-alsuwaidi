"""Turn a development layout into new surface properties and score it.

Layouts are written in fractional site coordinates (see config/scenarios.json),
rasterised onto the 10 m grid as:
    0 = unchanged, 1 = building, 2 = road / paving, 3 = new planted vegetation
"""

from dataclasses import dataclass, field

import numpy as np
from rasterio.features import rasterize
from shapely.geometry import LineString, box

from .grid import frac_to_xy
from .heat_model import scenario_lst

UNCHANGED, BUILDING, ROAD, GREEN = 0, 1, 2, 3
CLASS_NAMES = {UNCHANGED: "Unchanged", BUILDING: "Building", ROAD: "Road / paving", GREEN: "New planting"}


@dataclass
class Scenario:
    label: str
    plan: np.ndarray                     # class map, codes above
    zone: np.ndarray                     # development zone mask
    ndvi: np.ndarray = None
    built: np.ndarray = None
    bare: np.ndarray = None
    water: np.ndarray = None
    lst: np.ndarray = None
    d_lst: np.ndarray = None
    metrics: dict = field(default_factory=dict)


# ---------------------------------------------------------------- geometry
def _rect(grid, r):
    x0, y0 = frac_to_xy(grid, r[0], r[1])
    x1, y1 = frac_to_xy(grid, r[2], r[3])
    return box(x0, y0, x1, y1)


def _line(grid, pts):
    return LineString([frac_to_xy(grid, x, y) for x, y in pts])


def _burn(grid, geoms):
    if not geoms:
        return np.zeros((grid.height, grid.width), bool)
    return rasterize(
        [(g, 1) for g in geoms], out_shape=(grid.height, grid.width),
        transform=grid.transform, fill=0, dtype="uint8", all_touched=False,
    ).astype(bool)


def plan_from_features(grid, features, zone_rect, road_width_factor=1.0):
    plan = np.zeros((grid.height, grid.width), "uint8")
    for f in features:
        if f["type"] == "building":
            plan[_burn(grid, [_rect(grid, f["rect"])])] = BUILDING
    for f in features:
        if f["type"] == "road":
            w = f["width_m"] * road_width_factor
            plan[_burn(grid, [_line(grid, f["line"]).buffer(w / 2, cap_style="flat")])] = ROAD
    for f in features:
        if f["type"] == "green":
            geom = _rect(grid, f["rect"]) if "rect" in f else _line(grid, f["line"]).buffer(f.get("width_m", 10) / 2)
            plan[_burn(grid, [geom]) & (plan == UNCHANGED)] = GREEN
    zone = _burn(grid, [_rect(grid, zone_rect)])
    return plan, zone


def auto_green_alternative(grid, baseline, proposal, spec, scen_cfg, veg_threshold=0.3):
    """Greener version of the proposal with the SAME building footprint.

    1. Roads keep their alignment but are narrowed (road_width_factor).
    2. Building pixels that sit on existing vegetation are taken out and the
       vegetation is kept.
    3. The footprint removed in step 2 is added back by growing the remaining
       building blocks outward onto non-vegetated land inside the development
       zone, one pixel ring at a time, so buildings stay compact.
    4. Shade-tree verges are planted along the roads on non-vegetated land.
    """
    from scipy.ndimage import binary_dilation

    feats = scen_cfg["proposal"]["features"]
    zone_rect = scen_cfg["proposal"]["development_zone"]
    roads = [f for f in feats if f["type"] == "road"]
    plan, zone = plan_from_features(grid, roads, zone_rect, spec["road_width_factor"])

    from scipy.ndimage import label

    veg = np.nan_to_num(baseline.ndvi, nan=1.0) >= veg_threshold  # unknown pixels protected
    # Protect only real vegetation patches (trees, farm plots), not isolated pixels.
    min_px = max(1, int(round(spec.get("min_protected_patch_m2", 500) / grid.res ** 2)))
    lab, n = label(veg)
    if n:
        sizes = np.bincount(lab.ravel())
        keep = sizes >= min_px
        keep[0] = False
        veg = keep[lab]
    target = int((proposal.plan == BUILDING).sum())
    bldg = (proposal.plan == BUILDING) & ~veg & (plan == UNCHANGED)

    verge_geoms = []
    for f in roads:
        w = f["width_m"] * spec["road_width_factor"]
        verge_geoms.append(_line(grid, f["line"]).buffer(w / 2 + spec["tree_verge_width_m"], cap_style="flat"))
    verge = _burn(grid, verge_geoms) & (plan == UNCHANGED) & zone & ~veg

    allowed = zone & ~veg & (plan == UNCHANGED) & ~verge
    for _ in range(200):
        missing = target - int(bldg.sum())
        if missing <= 0:
            break
        ring = binary_dilation(bldg) & allowed & ~bldg
        if not ring.any():
            break
        if ring.sum() > missing:
            # keep the ring pixels with the lowest NDVI (least ecological value)
            idx = np.flatnonzero(ring)
            order = np.argsort(np.nan_to_num(baseline.ndvi.ravel()[idx], nan=1.0), kind="stable")
            ring = np.zeros_like(ring)
            ring.ravel()[idx[order[:missing]]] = True
        bldg |= ring

    # Not enough contiguous free land: place the remainder on the least-vegetated
    # free pixels anywhere in the zone, then (last resort) on verge land.
    for pool in (allowed & ~bldg, verge & ~bldg):
        missing = target - int(bldg.sum())
        if missing <= 0:
            break
        idx = np.flatnonzero(pool)
        order = np.argsort(np.nan_to_num(baseline.ndvi.ravel()[idx], nan=1.0), kind="stable")
        bldg.ravel()[idx[order[:missing]]] = True
    if bldg.sum() < target:
        print(f"Note: alternative B could place {bldg.sum()} of {target} building pixels without touching vegetation.")

    plan[verge & ~bldg] = GREEN
    plan[bldg] = BUILDING

    # Tree-planting requirement: new planting must reach a share of the building
    # footprint (greening_pct_of_built). Verges count first; any shortfall is
    # planted as shade trees on the open, least-vegetated land next to buildings
    # and roads inside the development zone (existing vegetation is kept as is).
    pct = spec.get("greening_pct_of_built", 0)
    need = int(round(pct / 100 * int(bldg.sum()))) - int((plan == GREEN).sum())
    if need > 0:
        open_land = zone & (plan == UNCHANGED) & ~veg
        for _ in range(200):
            if need <= 0:
                break
            ring = binary_dilation(plan != UNCHANGED) & open_land & (plan == UNCHANGED)
            if not ring.any():
                break
            idx = np.flatnonzero(ring)
            order = np.argsort(np.nan_to_num(baseline.ndvi.ravel()[idx], nan=1.0), kind="stable")
            take = idx[order[:need]]
            plan.ravel()[take] = GREEN
            need -= take.size
    return plan, zone


# ---------------------------------------------------------------- surfaces
def surface_targets(baseline, veg_threshold):
    """Representative NDVI for new surfaces, taken from the site itself."""
    built_px = baseline.ndvi[(baseline.landcover == 50) & np.isfinite(baseline.ndvi)]
    veg_px = baseline.ndvi[(baseline.ndvi >= veg_threshold) & np.isfinite(baseline.ndvi)]
    return {
        "ndvi_built": float(np.median(built_px)) if built_px.size >= 50 else 0.08,
        "ndvi_planted": float(np.median(veg_px)) if veg_px.size >= 50 else 0.45,
        "n_built_px": int(built_px.size),
        "n_veg_px": int(veg_px.size),
    }


def apply_plan(baseline, scenario, targets):
    p = scenario.plan
    sealed = (p == BUILDING) | (p == ROAD)
    planted = p == GREEN
    ndvi = baseline.ndvi.copy()
    built, bare, water = baseline.built.copy(), baseline.bare.copy(), baseline.water.copy()
    ndvi[sealed] = targets["ndvi_built"]
    ndvi[planted] = np.fmax(ndvi[planted], targets["ndvi_planted"])
    built[sealed], bare[sealed], water[sealed] = 1, 0, 0
    built[planted], bare[planted], water[planted] = 0, 0, 0
    scenario.ndvi, scenario.built, scenario.bare, scenario.water = ndvi, built, bare, water
    return scenario


# ---------------------------------------------------------------- scoring
def score(baseline, scenario, heat_model, veg_threshold, hot_threshold_c):
    scenario.lst, scenario.d_lst = scenario_lst(
        baseline, heat_model, scenario.ndvi, scenario.built, scenario.bare, scenario.water
    )
    ha = baseline.grid.res ** 2 / 1e4
    veg0 = baseline.ndvi >= veg_threshold
    veg1 = scenario.ndvi >= veg_threshold
    z = scenario.zone
    valid = np.isfinite(baseline.lst10)
    scenario.metrics = {
        "Scenario": scenario.label,
        "Built footprint (ha)": (scenario.plan == BUILDING).sum() * ha,
        "Roads / paving (ha)": (scenario.plan == ROAD).sum() * ha,
        "New planting (ha)": (scenario.plan == GREEN).sum() * ha,
        "Existing vegetation lost (ha)": (veg0 & ~veg1).sum() * ha,
        "Green cover, site (%)": 100 * veg1.mean(),
        "Mean LST change, dev. zone (degC)": float(np.nanmean(scenario.d_lst[z & valid])),
        "Peak LST change, p95 (degC)": float(np.nanpercentile(scenario.d_lst[z & valid], 95)),
        "Mean LST, site (degC)": float(np.nanmean(scenario.lst)),
        "Hotspot area > baseline p90 (ha)": (scenario.lst[valid] > hot_threshold_c).sum() * ha,
        "Area warmed > 1 degC (ha)": (scenario.d_lst[valid] > 1.0).sum() * ha,
    }
    return scenario


def baseline_metrics(baseline, zone, veg_threshold, hot_threshold_c):
    ha = baseline.grid.res ** 2 / 1e4
    valid = np.isfinite(baseline.lst10)
    return {
        "Scenario": "Existing site (satellite)",
        "Built footprint (ha)": 0.0,
        "Roads / paving (ha)": 0.0,
        "New planting (ha)": 0.0,
        "Existing vegetation lost (ha)": 0.0,
        "Green cover, site (%)": 100 * (baseline.ndvi >= veg_threshold).mean(),
        "Mean LST change, dev. zone (degC)": 0.0,
        "Peak LST change, p95 (degC)": 0.0,
        "Mean LST, site (degC)": float(np.nanmean(baseline.lst10)),
        "Hotspot area > baseline p90 (ha)": (baseline.lst10[valid] > hot_threshold_c).sum() * ha,
        "Area warmed > 1 degC (ha)": 0.0,
    }

"""Load the sample input and derive the baseline layers on the 10 m grid."""

import json
from dataclasses import dataclass

import numpy as np
import rasterio

from .grid import Grid

WORLDCOVER_CLASSES = {
    10: "Tree cover", 20: "Shrubland", 30: "Grassland", 40: "Cropland",
    50: "Built-up", 60: "Bare / sparse", 70: "Snow / ice", 80: "Water",
    90: "Wetland", 95: "Mangroves", 100: "Moss / lichen",
}
VEGETATION_CLASSES = [10, 20, 30, 40, 90, 95]


@dataclass
class Baseline:
    grid: Grid
    red: np.ndarray
    nir: np.ndarray
    swir: np.ndarray
    ndvi: np.ndarray
    ndbi: np.ndarray
    landcover: np.ndarray
    lst30: np.ndarray       # surface temperature, deg C, native 30 m grid
    lst10: np.ndarray       # same, repeated onto the 10 m grid (no new detail is invented)
    meta: dict

    @property
    def built(self):
        return (self.landcover == 50).astype("float32")

    @property
    def bare(self):
        return (self.landcover == 60).astype("float32")

    @property
    def water(self):
        return (self.landcover == 80).astype("float32")


def normalized_difference(a, b):
    with np.errstate(divide="ignore", invalid="ignore"):
        return (a - b) / (a + b)


def load_baseline(sample_dir):
    with rasterio.open(sample_dir / "s2_reflectance.tif") as src:
        red, nir, swir = src.read().astype("float32")
        grid = Grid(src.crs, src.transform, src.width, src.height)
    with rasterio.open(sample_dir / "worldcover.tif") as src:
        lc = src.read(1)
    with rasterio.open(sample_dir / "landsat_lst_celsius.tif") as src:
        lst30 = src.read(1).astype("float32")
    with open(sample_dir / "metadata.json", encoding="utf-8") as f:
        meta = json.load(f)

    lst10 = np.repeat(np.repeat(lst30, 3, axis=0), 3, axis=1)[: grid.height, : grid.width]
    return Baseline(
        grid=grid, red=red, nir=nir, swir=swir,
        ndvi=normalized_difference(nir, red),
        ndbi=normalized_difference(swir, nir),
        landcover=lc, lst30=lst30, lst10=lst10, meta=meta,
    )


def block_mean(a, factor=3):
    """Average a 10 m array onto the nested 30 m grid, ignoring NaNs."""
    h, w = (a.shape[0] // factor) * factor, (a.shape[1] // factor) * factor
    blocks = a[:h, :w].reshape(h // factor, factor, w // factor, factor)
    with np.errstate(invalid="ignore"):
        return np.nanmean(blocks, axis=(1, 3))


def landcover_summary(baseline, pixel_area_m2=100.0):
    rows = []
    total = baseline.landcover.size
    for code, name in WORLDCOVER_CLASSES.items():
        n = int((baseline.landcover == code).sum())
        if n:
            rows.append({"class": name, "area_ha": n * pixel_area_m2 / 1e4, "share_pct": 100 * n / total})
    return rows

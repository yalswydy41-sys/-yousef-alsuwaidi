"""Download and clip the three input datasets for the AOI in config/site.json.

Sources (all free, read anonymously from Microsoft Planetary Computer, no API key):
  * Sentinel-2 Level-2A surface reflectance (red, NIR, SWIR-1, scene classification)
  * Landsat 8/9 Collection 2 Level-2 surface temperature (band ST_B10, QA_PIXEL)
  * ESA WorldCover 2021 v200 land cover (10 m)

Each dataset is read straight from cloud-optimised GeoTIFFs, reprojected onto the
common UTM grid and written to data/sample_input/. Only the AOI is downloaded, so
the output is a few MB at most. The exact scene IDs and dates are recorded in
data/sample_input/metadata.json so the run is reproducible.
"""

import json
from datetime import datetime, timezone

import numpy as np
import planetary_computer
import pystac_client
import rasterio
from rasterio.enums import Resampling
from rasterio.vrt import WarpedVRT

from .config import SAMPLE_DIR, load_site
from .grid import grid_from_bbox

STAC_URL = "https://planetarycomputer.microsoft.com/api/stac/v1"

S2_CLOUD_CLASSES = [0, 1, 3, 8, 9, 10]  # no data, saturated, shadow, cloud med/high, cirrus
LANDSAT_ST_SCALE, LANDSAT_ST_OFFSET = 0.00341802, 149.0  # USGS Collection 2 Level-2 ST
GDAL_ENV = dict(
    GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR",
    CPL_VSIL_CURL_ALLOWED_EXTENSIONS=".tif,.TIF,.tiff",
    GDAL_HTTP_MAX_RETRY="4",
    GDAL_HTTP_RETRY_DELAY="2",
)


def read_to_grid(href, grid, resampling=Resampling.bilinear, dtype="float32"):
    """Read one raster asset, reprojected and clipped onto `grid`."""
    with rasterio.open(href) as src:
        with WarpedVRT(
            src,
            crs=grid.crs,
            transform=grid.transform,
            width=grid.width,
            height=grid.height,
            resampling=resampling,
            src_nodata=src.nodata,
            nodata=src.nodata,
        ) as vrt:
            return vrt.read(1).astype(dtype)


def _catalog():
    return pystac_client.Client.open(STAC_URL, modifier=planetary_computer.sign_inplace)


def _search(catalog, collection, bbox, dates, max_cloud, extra_query=None):
    query = {"eo:cloud_cover": {"lt": max_cloud}}
    query.update(extra_query or {})
    items = catalog.search(
        collections=[collection], bbox=bbox, datetime=dates, query=query
    ).item_collection()
    return sorted(items, key=lambda it: it.properties.get("eo:cloud_cover", 100))


def fetch_sentinel2(catalog, site, grid, min_valid=0.98):
    dates = f"{site['date_start']}/{site['date_end']}"
    items = _search(catalog, "sentinel-2-l2a", site["bbox"], dates, site["max_cloud_cover"])
    if not items:
        raise RuntimeError("No Sentinel-2 scene found. Widen the dates or raise max_cloud_cover.")
    for item in items[:10]:
        scl = read_to_grid(item.assets["SCL"].href, grid, Resampling.nearest, "uint8")
        valid = ~np.isin(scl, S2_CLOUD_CLASSES)
        if valid.mean() < min_valid:
            continue
        # Processing baseline >= 04.00 (Jan 2022 on) adds a +1000 offset to the DN values.
        baseline = float(item.properties.get("s2:processing_baseline", "0"))
        offset = 1000.0 if baseline >= 4.0 else 0.0
        bands = []
        for name, rs in (("B04", Resampling.bilinear), ("B08", Resampling.bilinear), ("B11", Resampling.bilinear)):
            dn = read_to_grid(item.assets[name].href, grid, rs)
            refl = (dn - offset) / 10000.0
            refl[~valid] = np.nan
            bands.append(np.clip(refl, 0, 1.5))
        meta = {
            "id": item.id,
            "datetime": item.properties["datetime"],
            "cloud_cover_scene_pct": item.properties.get("eo:cloud_cover"),
            "processing_baseline": baseline,
            "valid_fraction_aoi": round(float(valid.mean()), 4),
        }
        return np.stack(bands), meta
    raise RuntimeError("Every candidate Sentinel-2 scene is cloudy over the AOI.")


def fetch_landsat_lst(catalog, site, grid30, target_date, min_valid=0.95):
    dates = f"{site['date_start']}/{site['date_end']}"
    items = _search(
        catalog, "landsat-c2-l2", site["bbox"], dates, max(site["max_cloud_cover"], 20),
        {"platform": {"in": ["landsat-8", "landsat-9"]}},
    )
    if not items:
        raise RuntimeError("No Landsat scene found. Widen the dates or raise max_cloud_cover.")
    # Prefer the scene closest in time to the Sentinel-2 acquisition.
    t0 = datetime.fromisoformat(target_date.replace("Z", "+00:00"))
    items.sort(key=lambda it: abs((datetime.fromisoformat(it.properties["datetime"].replace("Z", "+00:00")) - t0).days))
    for item in items[:10]:
        qa = read_to_grid(item.assets["qa_pixel"].href, grid30, Resampling.nearest, "uint16")
        # QA_PIXEL bits: 0 fill, 1 dilated cloud, 3 cloud, 4 cloud shadow
        bad = (qa & 0b11011).astype(bool)
        if (~bad).mean() < min_valid:
            continue
        st = read_to_grid(item.assets["lwir11"].href, grid30, Resampling.bilinear)
        lst_c = st * LANDSAT_ST_SCALE + LANDSAT_ST_OFFSET - 273.15
        lst_c[bad | (st == 0)] = np.nan
        meta = {
            "id": item.id,
            "platform": item.properties.get("platform"),
            "datetime": item.properties["datetime"],
            "cloud_cover_scene_pct": item.properties.get("eo:cloud_cover"),
            "valid_fraction_aoi": round(float((~bad).mean()), 4),
        }
        return lst_c, meta
    raise RuntimeError("Every candidate Landsat scene is cloudy over the AOI.")


def fetch_worldcover(catalog, site, grid):
    items = list(catalog.search(collections=["esa-worldcover"], bbox=site["bbox"]).item_collection())
    items.sort(key=lambda it: it.properties.get("esa_worldcover:product_version", ""), reverse=True)
    item = items[0]
    lc = read_to_grid(item.assets["map"].href, grid, Resampling.nearest, "uint8")
    return lc, {"id": item.id, "version": item.properties.get("esa_worldcover:product_version")}


def _write(path, array, grid, dtype, nodata=None):
    arr = array if array.ndim == 3 else array[None]
    profile = dict(
        driver="GTiff", width=grid.width, height=grid.height, count=arr.shape[0],
        dtype=dtype, crs=grid.crs, transform=grid.transform, compress="deflate", nodata=nodata,
    )
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(arr.astype(dtype))


def download_sample(out_dir=SAMPLE_DIR, verbose=True):
    site = load_site()
    grid = grid_from_bbox(site["bbox"], res=site["pixel_size_m"])
    grid30 = grid.coarsen(3)
    out_dir.mkdir(parents=True, exist_ok=True)
    catalog = _catalog()
    with rasterio.Env(**GDAL_ENV):
        if verbose:
            print("Searching Sentinel-2 L2A ...")
        s2, s2_meta = fetch_sentinel2(catalog, site, grid)
        if verbose:
            print(f"  using {s2_meta['id']} ({s2_meta['datetime'][:10]})")
            print("Searching Landsat 8/9 Collection 2 L2 ...")
        lst, ls_meta = fetch_landsat_lst(catalog, site, grid30, s2_meta["datetime"])
        if verbose:
            print(f"  using {ls_meta['id']} ({ls_meta['datetime'][:10]})")
            print("Reading ESA WorldCover ...")
        lc, wc_meta = fetch_worldcover(catalog, site, grid)

    _write(out_dir / "s2_reflectance.tif", s2, grid, "float32", np.nan)
    _write(out_dir / "landsat_lst_celsius.tif", lst, grid30, "float32", np.nan)
    _write(out_dir / "worldcover.tif", lc, grid, "uint8", 0)
    meta = {
        "site": site,
        "grid": {"crs": grid.crs.to_string(), "pixel_size_m": grid.res, "width": grid.width, "height": grid.height},
        "sentinel2": s2_meta,
        "landsat": ls_meta,
        "worldcover": wc_meta,
        "stac_api": STAC_URL,
        "downloaded_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    with open(out_dir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    if verbose:
        print(f"Saved sample input to {out_dir}")
    return meta

"""Load project configuration and resolve repository paths."""

import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONFIG_DIR = ROOT / "config"
# Overridable with environment variables (used only for testing; defaults are the repo folders).
SAMPLE_DIR = Path(os.environ.get("BEFOREBUILD_SAMPLE_DIR", ROOT / "data" / "sample_input"))
RESULTS_DIR = Path(os.environ.get("BEFOREBUILD_RESULTS_DIR", ROOT / "results"))


def _load(name):
    with open(CONFIG_DIR / name, encoding="utf-8") as f:
        return json.load(f)


def load_site():
    return _load("site.json")


def load_scenarios():
    return _load("scenarios.json")

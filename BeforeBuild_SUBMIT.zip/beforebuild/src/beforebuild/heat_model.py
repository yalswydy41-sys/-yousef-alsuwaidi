"""Site-calibrated surface heat model.

Land surface temperature (LST) is regressed on surface properties that a
development changes: vegetation (NDVI) and the fraction of built-up, bare and
water surface. The model is fitted on the site itself at Landsat's native 30 m
resolution, so the coefficients describe this site on this date, not a generic
city.

    LST = b0 + b1*NDVI + b2*built + b3*bare + b4*water

A scenario changes NDVI and surface fractions. The predicted change is applied
to the OBSERVED temperature map (a delta method), so the spatial pattern in the
satellite data is kept and only the modelled change is added.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import GroupKFold

from .indices import block_mean

FEATURES = ["ndvi", "built", "bare", "water"]


@dataclass
class HeatModel:
    model: LinearRegression
    cv: dict
    table: pd.DataFrame

    @property
    def coefficients(self):
        return dict(zip(FEATURES, self.model.coef_))

    def predict_delta(self, d_ndvi, d_built, d_bare, d_water):
        c = self.coefficients
        return c["ndvi"] * d_ndvi + c["built"] * d_built + c["bare"] * d_bare + c["water"] * d_water


def training_table(baseline, block_cells=10):
    """One row per valid 30 m Landsat cell; `block` groups cells into 300 m tiles for spatial CV."""
    lst = baseline.lst30
    cols = {
        "lst": lst,
        "ndvi": block_mean(baseline.ndvi)[: lst.shape[0], : lst.shape[1]],
        "built": block_mean(baseline.built)[: lst.shape[0], : lst.shape[1]],
        "bare": block_mean(baseline.bare)[: lst.shape[0], : lst.shape[1]],
        "water": block_mean(baseline.water)[: lst.shape[0], : lst.shape[1]],
    }
    rr, cc = np.indices(lst.shape)
    cols["block"] = (rr // block_cells) * 1000 + (cc // block_cells)
    df = pd.DataFrame({k: v.ravel() for k, v in cols.items()})
    return df.dropna().reset_index(drop=True)


def fit_heat_model(baseline, n_splits=5):
    df = training_table(baseline)
    X, y, groups = df[FEATURES].values, df["lst"].values, df["block"].values

    # Spatial cross-validation: whole 300 m tiles are held out, so neighbouring
    # (spatially autocorrelated) cells cannot leak between train and test.
    n_splits = min(n_splits, len(np.unique(groups)))
    pred = np.empty_like(y)
    for tr, te in GroupKFold(n_splits=n_splits).split(X, y, groups):
        pred[te] = LinearRegression().fit(X[tr], y[tr]).predict(X[te])
    cv = {
        "n_cells_30m": int(len(df)),
        "cv_folds": int(n_splits),
        "cv_r2": float(r2_score(y, pred)),
        "cv_mae_c": float(mean_absolute_error(y, pred)),
        "lst_range_c": float(np.percentile(y, 95) - np.percentile(y, 5)),
    }
    df["cv_pred"] = pred
    return HeatModel(LinearRegression().fit(X, y), cv, df)


def scenario_lst(baseline, heat_model, ndvi_new, built_new, bare_new, water_new, spread_sigma_px=2.0):
    """Predicted LST map (10 m) for a scenario, via the delta method.

    `spread_sigma_px` smooths the change with a Gaussian kernel (2 px = 20 m) to
    represent the fact that a 30 m thermal pixel mixes neighbouring surfaces and
    that heat is exchanged laterally. The smoothing keeps the site-mean change.
    """
    d = heat_model.predict_delta(
        np.nan_to_num(ndvi_new - baseline.ndvi),
        built_new - baseline.built,
        bare_new - baseline.bare,
        water_new - baseline.water,
    )
    if spread_sigma_px:
        d = gaussian_filter(d, spread_sigma_px, mode="nearest")
    return baseline.lst10 + d, d

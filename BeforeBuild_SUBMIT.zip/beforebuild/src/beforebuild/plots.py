"""Figures written to results/."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, TwoSlopeNorm
from matplotlib.patches import Patch

from .indices import WORLDCOVER_CLASSES
from .scenarios import BUILDING, GREEN, ROAD

INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#898781", "#e1e0d9"
COL_BASE, COL_A, COL_B = "#898781", "#eb6834", "#1baf7a"
DIVERGING = LinearSegmentedColormap.from_list("cool_warm", ["#2a78d6", "#f0efec", "#e34948"])
PLAN_COLORS = {BUILDING: "#52514e", ROAD: "#0b0b0b", GREEN: "#008300"}
WC_COLORS = {
    10: "#006400", 20: "#ffbb22", 30: "#ffff4c", 40: "#f096ff", 50: "#fa0000", 60: "#b4b4b4",
    70: "#f0f0f0", 80: "#0064c8", 90: "#0096a0", 95: "#00cf75", 100: "#fae6a0",
}

plt.rcParams.update({
    "font.size": 10, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": INK2,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.titleweight": "bold",
    "axes.titlesize": 11, "figure.facecolor": "white", "savefig.dpi": 150,
})


def _off(ax):
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)


def _scalebar(ax, grid, length_m=500):
    px = length_m / grid.res
    x0, y0 = grid.width * 0.05, grid.height * 0.94
    ax.plot([x0, x0 + px], [y0, y0], color="white", lw=4, solid_capstyle="butt")
    ax.plot([x0, x0 + px], [y0, y0], color=INK, lw=2, solid_capstyle="butt")
    ax.text(x0 + px / 2, y0 - grid.height * 0.025, f"{length_m} m", ha="center", va="bottom",
            fontsize=8, color=INK, bbox=dict(fc="white", ec="none", alpha=0.7, pad=1))


def false_color(b):
    """SWIR-1 / NIR / Red composite: vegetation green, built-up purple-grey, bare soil tan."""
    rgb = np.dstack([b.swir, b.nir, b.red])
    lo, hi = np.nanpercentile(rgb, 2), np.nanpercentile(rgb, 98)
    return np.nan_to_num(np.clip((rgb - lo) / (hi - lo), 0, 1))


def baseline_maps(b, path, veg_threshold):
    fig, axes = plt.subplots(1, 4, figsize=(17, 4.6), constrained_layout=True)
    ax = axes[0]; ax.imshow(false_color(b)); ax.set_title("Sentinel-2 false colour (SWIR/NIR/red)"); _scalebar(ax, b.grid)

    ax = axes[1]; im = ax.imshow(b.ndvi, cmap="Greens", vmin=0, vmax=0.8)
    ax.contour(b.ndvi >= veg_threshold, levels=[0.5], colors=INK, linewidths=0.6)
    ax.set_title(f"NDVI (outline: vegetation, NDVI >= {veg_threshold})")
    fig.colorbar(im, ax=ax, shrink=0.8, label="NDVI")

    ax = axes[2]
    codes = sorted(np.unique(b.landcover))
    cmap = ListedColormap([WC_COLORS.get(c, "#000000") for c in codes])
    idx = np.searchsorted(codes, b.landcover)
    ax.imshow(idx, cmap=cmap, vmin=-0.5, vmax=len(codes) - 0.5, interpolation="nearest")
    ax.set_title("ESA WorldCover 2021 land cover")
    ax.legend(handles=[Patch(color=WC_COLORS.get(c), label=WORLDCOVER_CLASSES.get(c, str(c))) for c in codes],
              loc="lower right", fontsize=7, framealpha=0.85)

    ax = axes[3]
    im = ax.imshow(b.lst30, cmap="OrRd", extent=(-0.5, b.grid.width - 0.5, b.grid.height - 0.5, -0.5))
    ax.set_title("Landsat land surface temperature")
    fig.colorbar(im, ax=ax, shrink=0.8, label="degC")
    for a in axes:
        _off(a)
    s2d, lsd = b.meta["sentinel2"]["datetime"][:10], b.meta["landsat"]["datetime"][:10]
    fig.suptitle(f"Existing site - {b.meta['site']['site_name']}   (Sentinel-2 {s2d}, Landsat {lsd})",
                 fontsize=12, fontweight="bold", color=INK)
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)


def _plan_overlay(ax, b, sc):
    base = false_color(b)
    grey = base.mean(axis=2, keepdims=True).repeat(3, axis=2)
    ax.imshow(0.35 * base + 0.65 * (0.55 + 0.45 * grey))
    rgba = np.zeros((*sc.plan.shape, 4))
    for code, hexcol in PLAN_COLORS.items():
        m = sc.plan == code
        rgba[m, :3] = matplotlib.colors.to_rgb(hexcol)
        rgba[m, 3] = 0.92
    ax.imshow(rgba, interpolation="nearest")
    ax.contour(sc.zone, levels=[0.5], colors=MUTED, linewidths=1, linestyles="--")


def scenario_comparison(b, scenarios, metrics_df, path):
    A, B = scenarios
    fig = plt.figure(figsize=(13, 16.5), constrained_layout=True)
    gs = fig.add_gridspec(3, 2, height_ratios=[1, 1, 0.62])
    lim = float(np.nanmax(np.abs(np.concatenate([np.nanpercentile(A.d_lst, [0.5, 99.5]), np.nanpercentile(B.d_lst, [0.5, 99.5])]))))
    norm = TwoSlopeNorm(vcenter=0, vmin=-max(lim, 0.5), vmax=max(lim, 0.5))
    for col, sc in enumerate((A, B)):
        ax = fig.add_subplot(gs[0, col]); _plan_overlay(ax, b, sc); _off(ax); _scalebar(ax, b.grid)
        ax.set_title(f"{sc.label}: layout")
        if col == 0:
            ax.legend(handles=[Patch(color=PLAN_COLORS[BUILDING], label="Building"),
                               Patch(color=PLAN_COLORS[ROAD], label="Road / paving"),
                               Patch(color=PLAN_COLORS[GREEN], label="New planting"),
                               Patch(fc="none", ec=MUTED, ls="--", label="Development zone")],
                      loc="lower right", fontsize=8, framealpha=0.9)
        ax = fig.add_subplot(gs[1, col])
        im = ax.imshow(sc.d_lst, cmap=DIVERGING, norm=norm)
        ax.contour(sc.zone, levels=[0.5], colors=MUTED, linewidths=1, linestyles="--")
        _off(ax)
        m = sc.metrics
        ax.set_title(f"{sc.label.split(' - ')[0]}: predicted surface temperature change\n"
                     f"zone mean {m['Mean LST change, dev. zone (degC)']:+.2f} degC, "
                     f"95th pct {m['Peak LST change, p95 (degC)']:+.2f} degC")
        fig.colorbar(im, ax=ax, shrink=0.75, label="Change vs. today (degC)", location="bottom", pad=0.02)

    names = ["Today", "A", "B"]
    cols = [COL_BASE, COL_A, COL_B]
    keys = [("Mean LST change, dev. zone (degC)", "Mean LST change\nin zone (degC)"),
            ("New planting (ha)", "New shade-tree\nplanting (ha)"),
            ("Existing vegetation lost (ha)", "Existing vegetation\nlost (ha)"),
            ("Green cover, site (%)", "Green cover\nof site (%)")]
    sub = gs[2, :].subgridspec(1, 4, wspace=0.45)
    for i, (k, t) in enumerate(keys):
        ax = fig.add_subplot(sub[0, i])
        vals = metrics_df[k].values
        bars = ax.bar(names, vals, color=cols, width=0.6, edgecolor="white", linewidth=2)
        for bar, v in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, v, f"{v:+.2f}" if "change" in k else f"{v:.1f}",
                    ha="center", va="bottom" if v >= 0 else "top", fontsize=9, color=INK)
        ax.set_title(t, fontsize=10)
        ax.spines[["top", "right"]].set_visible(False)
        ax.yaxis.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
        ax.axhline(0, color="#c3c2b7", lw=1)
        ax.margins(y=0.2)
    fig.suptitle("Proposal A vs. greener alternative B (same building footprint)",
                 fontsize=14, fontweight="bold", color=INK)
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)


def model_validation(hm, path):
    df = hm.table
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.4), constrained_layout=True)
    ax = axes[0]
    ax.scatter(df["lst"], df["cv_pred"], s=10, color="#2a78d6", alpha=0.45, edgecolor="none")
    lo, hi = np.percentile(df[["lst", "cv_pred"]].values, [0.5, 99.5])
    ax.plot([lo, hi], [lo, hi], color=INK2, lw=1, ls="--")
    ax.set_xlabel("Observed LST (degC, Landsat 30 m)")
    ax.set_ylabel("Predicted LST, held-out tile (degC)")
    cv = hm.cv
    ax.set_title(f"Spatial cross-validation ({cv['cv_folds']} folds, 300 m tiles)\n"
                 f"R2 = {cv['cv_r2']:.2f}, MAE = {cv['cv_mae_c']:.2f} degC, n = {cv['n_cells_30m']}")
    ax.grid(color=GRID, lw=0.6)
    ax = axes[1]
    labels = {"ndvi": "NDVI\n(per +1.0)", "built": "Built-up\n(per 100%)", "bare": "Bare soil\n(per 100%)", "water": "Water\n(per 100%)"}
    coefs = hm.coefficients
    keys = list(labels)
    vals = [coefs[k] for k in keys]
    bars = ax.bar([labels[k] for k in keys], vals, color=["#2a78d6" if v < 0 else "#e34948" for v in vals],
                  width=0.6, edgecolor="white", linewidth=2)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width() / 2, v, f"{v:+.1f}", ha="center",
                va="bottom" if v >= 0 else "top", fontsize=9, color=INK)
    ax.axhline(0, color="#c3c2b7", lw=1)
    ax.set_ylabel("Effect on LST (degC)")
    ax.set_title("Site-calibrated heat coefficients")
    ax.spines[["top", "right"]].set_visible(False)
    ax.margins(y=0.2)
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)

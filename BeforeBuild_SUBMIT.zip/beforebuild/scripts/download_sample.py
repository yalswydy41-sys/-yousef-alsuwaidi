"""Download the sample input for the AOI in config/site.json into data/sample_input/.

Usage (from the repository root):
    python scripts/download_sample.py

No API key or account is needed. Data are read from Microsoft Planetary Computer.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from beforebuild.download import download_sample  # noqa: E402

if __name__ == "__main__":
    download_sample()

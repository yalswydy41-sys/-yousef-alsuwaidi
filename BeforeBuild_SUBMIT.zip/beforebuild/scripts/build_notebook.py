"""Developer helper: regenerates notebooks/02_main_analysis.ipynb from the cell text below.

Reviewers do not need this; open the notebook directly.
"""

from pathlib import Path

import nbformat as nbf

md, code = nbf.v4.new_markdown_cell, nbf.v4.new_code_cell
cells = []

cells.append(md("""# BeforeBuild - assessing urban development impact before construction

**Theme:** Urban planning and smart cities

This notebook is the full proof of concept. For a proposed development site it:

1. downloads and clips satellite data for the site (Sentinel-2, Landsat 8/9, ESA WorldCover),
2. maps today's vegetation, land cover and land surface temperature (LST),
3. calibrates a heat model **on this site** from the satellite data,
4. applies a **proposed layout (A)** and an automatically generated **greener alternative (B)** with the same building footprint,
5. estimates the change in green space and surface heat for each, and reports which design has the lower impact.

**Run:** `Kernel -> Restart Kernel and Run All Cells`. About 3-6 minutes on a laptop the first time (download), under 1 minute afterwards. No GPU, no API keys.

**What to edit:** `config/site.json` (site location and dates) and `config/scenarios.json` (the development layout). Nothing in this notebook needs to change."""))

cells.append(md("## 1. Setup"))
cells.append(code("""import json
import random
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# Relative paths only: works from the repo root or from notebooks/
ROOT = Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()
sys.path.insert(0, str(ROOT / "src"))

from beforebuild import config, heat_model, indices, plots, scenarios
from beforebuild.download import download_sample

SEED = config.load_site()["random_seed"]
random.seed(SEED)
np.random.seed(SEED)
pd.set_option("display.precision", 2)

SAMPLE_DIR, RESULTS_DIR = config.SAMPLE_DIR, config.RESULTS_DIR
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
print("Repository root:", ROOT.name)"""))

cells.append(md("## 2. Site configuration"))
cells.append(code("""site = config.load_site()
scen_cfg = config.load_scenarios()
VEG_T = site["vegetation_ndvi_threshold"]
{k: v for k, v in site.items() if not k.startswith("_")}"""))

cells.append(md("""## 3. Input data

The sample input in `data/sample_input/` is a small clip of the site. If it is missing, or `config/site.json` now points to a different site, it is downloaded again from Microsoft Planetary Computer (free, anonymous). The scene IDs used are stored in `data/sample_input/metadata.json`."""))
cells.append(code("""def sample_matches_site():
    meta_path = SAMPLE_DIR / "metadata.json"
    needed = ["s2_reflectance.tif", "landsat_lst_celsius.tif", "worldcover.tif"]
    if not meta_path.exists() or not all((SAMPLE_DIR / n).exists() for n in needed):
        return False
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    keys = ["bbox", "date_start", "date_end", "max_cloud_cover", "pixel_size_m"]
    return all(meta["site"].get(k) == site.get(k) for k in keys)

if sample_matches_site():
    print("Using committed sample input in data/sample_input/")
else:
    print("Sample input missing or out of date - downloading (a few minutes) ...")
    download_sample(SAMPLE_DIR)

meta = json.loads((SAMPLE_DIR / "metadata.json").read_text(encoding="utf-8"))
pd.DataFrame({
    "Dataset": ["Sentinel-2 L2A", "Landsat C2 L2 (surface temperature)", "ESA WorldCover"],
    "Scene / tile": [meta["sentinel2"]["id"], meta["landsat"]["id"], meta["worldcover"]["id"]],
    "Date": [meta["sentinel2"]["datetime"][:10], meta["landsat"]["datetime"][:10], "2021 (v" + str(meta["worldcover"]["version"]) + ")"],
})"""))

cells.append(md("## 4. The existing site"))
cells.append(code("""base = indices.load_baseline(SAMPLE_DIR)
g = base.grid
print(f"Grid: {g.width} x {g.height} pixels at {g.res:.0f} m = {g.width*g.res/1000:.2f} x {g.height*g.res/1000:.2f} km ({g.crs.to_string()})")
print(f"Valid pixels - Sentinel-2: {np.isfinite(base.ndvi).mean():.1%}, Landsat LST: {np.isfinite(base.lst30).mean():.1%}")
print(f"Vegetation (NDVI >= {VEG_T}): {(base.ndvi >= VEG_T).mean():.1%} of site")
print(f"Surface temperature: mean {np.nanmean(base.lst30):.1f} degC, range p5-p95 {np.nanpercentile(base.lst30, 5):.1f}-{np.nanpercentile(base.lst30, 95):.1f} degC")
pd.DataFrame(indices.landcover_summary(base))"""))
cells.append(code("""plots.baseline_maps(base, RESULTS_DIR / "baseline_maps.png", VEG_T)
from IPython.display import Image, display
display(Image(str(RESULTS_DIR / "baseline_maps.png")))"""))

cells.append(md("""## 5. Site-calibrated heat model

LST is regressed on NDVI and the fractions of built-up, bare and water surface at Landsat's native 30 m. Accuracy is measured with **spatial cross-validation**: 300 m tiles are held out whole, so neighbouring pixels cannot leak between training and test. Physically, the NDVI coefficient should be negative (vegetation cools through evapotranspiration and shade)."""))
cells.append(code("""hm = heat_model.fit_heat_model(base)
coef = pd.Series(hm.coefficients, name="degC per unit change")
display(coef.to_frame())
print({k: round(v, 3) for k, v in hm.cv.items()})
if hm.coefficients["ndvi"] >= 0:
    print("WARNING: NDVI coefficient is not negative on this site/date - interpret scenario results with care.")
plots.model_validation(hm, RESULTS_DIR / "model_validation.png")
display(Image(str(RESULTS_DIR / "model_validation.png")))"""))

cells.append(md("""## 6. Development scenarios

* **A - Conventional proposal:** the layout drawn in `config/scenarios.json` (buildings and roads), placed without regard to what is on the ground.
* **B - Greener alternative (auto):** the **same building footprint** as A. Building area that would sit on existing vegetation patches (at least 500 m2: trees, farm plots) is removed, the vegetation is kept, and the same area is added back by growing the blocks onto non-vegetated land. Roads keep their alignment but are 30% narrower, and 10 m shade-tree verges are planted along them. New tree planting is required to reach **15% of the building footprint** (the team's proposed 10-15% greening rule); any shortfall after the verges is planted next to buildings and roads on open land.

New surfaces take their values from the site itself: sealed surfaces get the median NDVI of existing built-up pixels, new planting the median NDVI of existing vegetation."""))
cells.append(code("""p = scen_cfg["proposal"]
planA, zone = scenarios.plan_from_features(g, p["features"], p["development_zone"])
A = scenarios.Scenario(p["label"], planA, zone)

bcfg = scen_cfg["green_alternative"]
if bcfg.get("mode", "auto") == "auto":
    planB, zoneB = scenarios.auto_green_alternative(g, base, A, bcfg, scen_cfg, VEG_T)
else:
    planB, zoneB = scenarios.plan_from_features(g, bcfg["features"], p["development_zone"])
B = scenarios.Scenario(bcfg["label"], planB, zoneB)

targets = scenarios.surface_targets(base, VEG_T)
print("Surface values taken from the site:", targets)

hot_t = float(np.nanpercentile(base.lst10, 90))
for sc in (A, B):
    scenarios.apply_plan(base, sc, targets)
    scenarios.score(base, sc, hm, VEG_T, hot_t)

metrics = pd.DataFrame([scenarios.baseline_metrics(base, zone, VEG_T, hot_t), A.metrics, B.metrics]).set_index("Scenario")
metrics.to_csv(RESULTS_DIR / "scenario_metrics.csv", float_format="%.3f")
metrics.T"""))

cells.append(code("""plots.scenario_comparison(base, (A, B), metrics.reset_index(), RESULTS_DIR / "scenario_comparison.png")
shutil.copyfile(RESULTS_DIR / "scenario_comparison.png", RESULTS_DIR / "example_output.png")
display(Image(str(RESULTS_DIR / "scenario_comparison.png")))"""))

cells.append(md("## 7. Recommendation"))
cells.append(code("""mA, mB = A.metrics, B.metrics
KEY_T, KEY_V, KEY_W = "Mean LST change, dev. zone (degC)", "Existing vegetation lost (ha)", "Area warmed > 1 degC (ha)"
dA, dB = mA[KEY_T], mB[KEY_T]
# Rank by: area that gets > 1 degC hotter, then existing vegetation lost, then mean change.
better = B if (mB[KEY_W], mB[KEY_V], dB) <= (mA[KEY_W], mA[KEY_V], dA) else A

summary = {
    "site": site["site_name"],
    "recommended_design": better.label,
    "building_footprint_ha": {"A": round(mA["Built footprint (ha)"], 2), "B": round(mB["Built footprint (ha)"], 2)},
    "mean_lst_change_zone_degC": {"A": round(dA, 2), "B": round(dB, 2)},
    "B_minus_A_degC": round(dB - dA, 2),
    "vegetation_lost_ha": {"A": round(mA[KEY_V], 2), "B": round(mB[KEY_V], 2)},
    "area_warmed_over_1C_ha": {"A": round(mA[KEY_W], 2), "B": round(mB[KEY_W], 2)},
    "green_cover_site_pct": {"today": round(metrics.loc[metrics.index[0], "Green cover, site (%)"], 2), "A": round(mA["Green cover, site (%)"], 2), "B": round(mB["Green cover, site (%)"], 2)},
    "model_cv_r2": round(hm.cv["cv_r2"], 3),
    "model_cv_mae_degC": round(hm.cv["cv_mae_c"], 3),
    "scenes": {"sentinel2": meta["sentinel2"]["id"], "landsat": meta["landsat"]["id"]},
}
(RESULTS_DIR / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

print(f"Recommended: {better.label}")
print(f"  Building footprint: A {mA['Built footprint (ha)']:.2f} ha, B {mB['Built footprint (ha)']:.2f} ha")
print(f"  Mean surface temperature change in the development zone: A {dA:+.2f} degC, B {dB:+.2f} degC "
      f"(B is {abs(dB - dA):.2f} degC {'cooler' if dB < dA else 'warmer'} than A)")
print(f"  Existing vegetation lost: A {mA[KEY_V]:.2f} ha, B {mB[KEY_V]:.2f} ha")
print(f"  Area that gets more than 1 degC hotter: A {mA[KEY_W]:.1f} ha, B {mB[KEY_W]:.1f} ha")
print(f"  Green cover of the site: today {summary['green_cover_site_pct']['today']:.1f}%, A {mA['Green cover, site (%)']:.1f}%, B {mB['Green cover, site (%)']:.1f}%")
if min(dA, dB) < 0:
    print("  Note: a negative mean change means the new surfaces are cooler BY DAY than the bare desert "
          "they replace (bare sand is the hottest surface here at ~10:30). That is why the ranking uses "
          "the area that gets hotter and the vegetation lost, not the zone mean.")"""))

cells.append(md("""## 8. Sensitivity check

Does the ranking hold if our assumptions are off? We vary the heat-spread kernel and the NDVI assumed for new planting and for sealed surfaces, and recount the area that gets more than 1 degC hotter."""))
cells.append(code("""rows = []
for sigma in (0, 2, 4):
    for planted in (0.8, 1.0, 1.2):
        for sealed in (0.8, 1.0, 1.5):
            t = dict(targets, ndvi_planted=targets["ndvi_planted"] * planted, ndvi_built=targets["ndvi_built"] * sealed)
            res = {}
            for name, sc in (("A", A), ("B", B)):
                s = scenarios.apply_plan(base, scenarios.Scenario(sc.label, sc.plan, sc.zone), t)
                _, d = heat_model.scenario_lst(base, hm, s.ndvi, s.built, s.bare, s.water, spread_sigma_px=sigma)
                ok = np.isfinite(base.lst10)
                res[name] = float(np.nanmean(d[s.zone & ok]))
                res[name + "_warmed_ha"] = float((d[ok] > 1.0).sum() * g.res ** 2 / 1e4)
            rows.append({"spread_sigma_px": sigma, "planted_ndvi_x": planted, "sealed_ndvi_x": sealed,
                         "A_lst_change": res["A"], "B_lst_change": res["B"],
                         "A_warmed_ha": res["A_warmed_ha"], "B_warmed_ha": res["B_warmed_ha"],
                         "B_better": res["B"] < res["A"]})
sens = pd.DataFrame(rows)
sens.to_csv(RESULTS_DIR / "sensitivity.csv", index=False, float_format="%.3f")
print(f"B has the lower mean surface temperature change in {sens['B_better'].sum()} of {len(sens)} assumption combinations")
print(f"Area warmed > 1 degC: A {sens['A_warmed_ha'].min():.1f}-{sens['A_warmed_ha'].max():.1f} ha, B {sens['B_warmed_ha'].min():.1f}-{sens['B_warmed_ha'].max():.1f} ha")
print(f"A zone LST change range: {sens['A_lst_change'].min():+.2f} to {sens['A_lst_change'].max():+.2f} degC; "
      f"B: {sens['B_lst_change'].min():+.2f} to {sens['B_lst_change'].max():+.2f} degC")"""))

cells.append(md("""## 8b. Tree-planting requirement: 0%, 10% and 15% of the building footprint

The team proposes requiring new tree planting equal to 10-15% of the building area. This cell rebuilds alternative B with three levels of that rule and compares the results."""))
cells.append(code("""rows = []
for pct in (0, 10, 15):
    spec = dict(bcfg, greening_pct_of_built=pct)
    planG, zoneG = scenarios.auto_green_alternative(g, base, A, spec, scen_cfg, VEG_T)
    sG = scenarios.apply_plan(base, scenarios.Scenario(f"B, {pct}% planting", planG, zoneG), targets)
    scenarios.score(base, sG, hm, VEG_T, hot_t)
    m = sG.metrics
    rows.append({"Planting rule (% of building area)": pct,
                 "New planting (ha)": m["New planting (ha)"],
                 "Green cover, site (%)": m["Green cover, site (%)"],
                 "Mean LST change, dev. zone (degC)": m["Mean LST change, dev. zone (degC)"]})
greening = pd.DataFrame(rows).set_index("Planting rule (% of building area)")
greening.to_csv(RESULTS_DIR / "greening_rule.csv", float_format="%.3f")
greening"""))

cells.append(md("""## 9. Limitations

* **Surface, not air, temperature.** Landsat measures land surface temperature at one overpass (~10:30 local time). Air temperature and night-time heat are not modelled.
* **Single-date calibration.** The heat coefficients describe this site on the scene date. Running several summer dates would give a range.
* **Thermal resolution.** Landsat thermal band 10 is acquired at 100 m and delivered resampled to 30 m by USGS. We do not sharpen it; the 10 m maps show modelled change, not new thermal detail.
* **Linear model.** Shading by tall buildings, building materials, irrigation and wind are not represented.
* **New planting needs water.** In an arid climate the cooling of new vegetation assumes it is irrigated and survives; the water cost is not yet estimated.
* **Land cover is from 2021.** ESA WorldCover may miss recent change; NDVI from the current Sentinel-2 scene is used for vegetation itself.

Outputs written: `results/baseline_maps.png`, `results/model_validation.png`, `results/scenario_comparison.png` (= `example_output.png`), `results/scenario_metrics.csv`, `results/sensitivity.csv`, `results/greening_rule.csv`, `results/run_summary.json`."""))

nb = nbf.v4.new_notebook()
nb["cells"] = cells
nb["metadata"] = {
    "kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"},
    "language_info": {"name": "python"},
}
out = Path(__file__).resolve().parents[1] / "notebooks" / "02_main_analysis.ipynb"
nbf.write(nb, out)
print("wrote", out)

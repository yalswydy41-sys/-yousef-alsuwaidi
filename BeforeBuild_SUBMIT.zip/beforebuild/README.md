# BeforeBuild: assessing urban development impact before construction

**Team members:** Yousef Al Suwaidi, Fatema Al Ajmi, Maather Al Siyabi, Abdullah Khamis Al Araimi, Mariya Al Hasni  
**Theme:** Urban planning and smart cities  
**Represented country:** United Arab Emirates  
**Site:** Digdaga, Ras Al Khaimah (centre 25.661 N, 55.968 E)  
**Proof of concept:** a reproducible Jupyter notebook that uses Sentinel-2, Landsat 8/9 and ESA WorldCover to map a site's vegetation, land cover and surface temperature, then estimates how a proposed development layout, and a greener alternative with the same building footprint, would change green space and surface heat.

![Proposal A vs. greener alternative B](results/example_output.png)

---

## 1. Summary

Urban planners and developers usually find out what a project does to heat and green space after it is built, when the layout can no longer change. BeforeBuild moves that check to the concept stage. For any site, it reads free satellite data, calibrates a heat model on that site, applies a proposed layout, and generates a greener alternative that keeps the same building footprint. It reports, per design: existing vegetation lost, green cover, change in land surface temperature (LST), and the area that becomes hotter than today's hottest 10%.

## 2. Business use case

| | |
|---|---|
| **Users** | Municipal planners (primary), developers and urban design / engineering consultancies. Residents are affected by the result: they live with the vegetation and surfaces the layout leaves behind. |
| **Decision** | During early design review, a municipal planner compares a hypothetical residential development with a greener alternative to identify vegetation conflicts and opportunities to reduce sealed surfaces, before the layout is finalised. |
| **What they use today** | Expert judgement, site visits, and, for large projects, environmental studies commissioned late in the process from consultants. Microclimate simulation tools (e.g. ENVI-met) exist but need specialists and days of setup per scenario. |
| **What BeforeBuild adds** | A screening result in minutes from public data, for any site, with two designs side by side. It is a pre-screening tool, not a replacement for a full environmental impact assessment. |

## 3. The problem

Cities in the Gulf are expanding onto farmland, date-palm groves and desert fringes. Each conversion removes vegetation that cools its surroundings and replaces it with sealed surfaces. In a climate where summer land surface temperatures exceed 50 degC, losing that vegetation intensifies heat stress, raises cooling energy demand and reduces outdoor comfort. The damage is decided at the layout stage, but the information to see it is rarely available at that stage.

Satellite data is the right instrument because it measures, for any site and without a field campaign, the three things a layout changes: vegetation (Sentinel-2 NDVI at 10 m), land cover (ESA WorldCover at 10 m) and surface temperature (Landsat thermal band). It covers every site in the region every few days, for free, which makes the check possible for every project rather than only the largest.

## 4. Data used

| Dataset | Provider | Product / processing level | Use | Dates | Licence |
|---|---|---|---|---|---|
| Sentinel-2 MSI | ESA / Copernicus, via Microsoft Planetary Computer | Level-2A surface reflectance, bands B04 (red), B08 (NIR), B11 (SWIR-1), SCL (scene classification) | NDVI, NDBI, cloud mask, false-colour image | Least-cloudy scene over the site, 11 June 2025 (`S2C_MSIL2A_20250611T064641_R020_T40RCP_20250611T123230`) | Copernicus Sentinel data, free, full and open ([legal notice](https://sentinels.copernicus.eu/documents/247904/690755/Sentinel_Data_Legal_Notice)) |
| Landsat 8 / 9 OLI-TIRS | USGS, via Microsoft Planetary Computer | Collection 2 Level-2, band ST_B10 (surface temperature) and QA_PIXEL | Land surface temperature, cloud mask | Scene closest in date to the Sentinel-2 scene, 9 June 2025, Landsat 9 (`LC09_L2SP_160042_20250609_02_T1`) | Public domain (USGS) |
| ESA WorldCover | ESA | 2021, v200, 10 m land cover map | Built-up, bare, water, vegetation classes | 2021 | CC BY 4.0, © ESA WorldCover project 2021 / Contains modified Copernicus Sentinel data (2021) processed by ESA WorldCover consortium |

Search window: 1 May to 30 September 2025 (summer), scene cloud cover below 10% (20% for Landsat), and at least 98% (Sentinel-2) / 95% (Landsat) clear pixels over the site. The exact scene IDs used are written to `data/sample_input/metadata.json`. **Hyperspectral data is not used in this proof of concept**; see Results and limitations.

## 5. Technical approach

The notebook runs these steps in order:

1. **Common grid.** The site box in `config/site.json` is converted to a 10 m grid in local UTM (EPSG:32640 for Ras Al Khaimah), snapped to 30 m so the Landsat grid nests exactly (one 30 m cell = 3 x 3 cells).
2. **Download and clip** (`src/beforebuild/download.py`). Cloud-optimised GeoTIFFs are read for the site only and reprojected onto the grid. Sentinel-2 digital numbers are converted to reflectance with the processing-baseline offset (DN - 1000) / 10000 for baseline 04.00 and later. Landsat ST_B10 is converted to degC with the USGS scale factors (DN x 0.00341802 + 149.0 - 273.15). Clouds, shadows and cirrus are masked with SCL and QA_PIXEL.
3. **Indices.** NDVI = (NIR - red) / (NIR + red); NDBI = (SWIR1 - NIR) / (SWIR1 + NIR). Vegetation is NDVI >= 0.3.
4. **Site-calibrated heat model** (`src/beforebuild/heat_model.py`). At Landsat's 30 m, LST is regressed on mean NDVI and the fractions of built-up, bare and water cover:  
   `LST = b0 + b1*NDVI + b2*built + b3*bare + b4*water`  
   Accuracy is measured with 5-fold **spatial** cross-validation (300 m tiles held out whole). Random seed 42.
5. **Scenarios** (`src/beforebuild/scenarios.py`, layout in `config/scenarios.json`).
   - **A, conventional proposal (hypothetical residential development):** nine building blocks (72 ha) and a road grid on the undeveloped south-east fringe of Digdaga, placed without reference to what is on the ground.
   - **B, greener alternative (generated automatically):** the same building footprint as A. Building area that falls on existing vegetation patches of at least 500 m2 (trees, farm plots) is removed and re-added by growing the blocks onto non-vegetated land; roads keep their alignment but are 30% narrower; 10 m shade-tree verges are planted along roads. Total new tree planting must reach 15% of the building footprint (the team's proposed 10-15% greening rule); any shortfall after the verges is planted next to buildings and roads on open land.
   - New sealed surfaces take the median NDVI of existing built-up pixels on the site; new planting takes the median NDVI of existing vegetation on the site.
6. **Predict and compare.** The modelled change is added to the observed LST map (delta method), spread with a Gaussian kernel (sigma 20 m) to represent lateral mixing. Each design is scored on: existing vegetation lost (ha), green cover (%), new planting (ha), mean and 95th-percentile LST change in the development zone (degC), area that gets more than 1 degC hotter (ha), and area hotter than today's 90th percentile (ha). Designs are ranked by the area that gets more than 1 degC hotter, then by existing vegetation lost, then by mean LST change.
7. **Sensitivity.** The ranking is recomputed for 27 combinations of the spread kernel and the NDVI assumed for new planting and sealed surfaces.

## 6. Installation

Requires **Python 3.11** (3.12 also works). No GPU, no API keys, no accounts.

```bash
git clone https://github.com/<your-github-user>/beforebuild.git
cd beforebuild
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 7. How to run

```bash
jupyter lab notebooks/02_main_analysis.ipynb
```

Then **Kernel -> Restart Kernel and Run All Cells**.

- **Runtime:** under 1 minute with the committed sample input on a standard laptop. If `config/site.json` is changed to a new site, the notebook downloads that site's data first (a few MB, about 3-6 minutes, needs internet).
- **What to edit:** `config/site.json` for the site location (`bbox` in WGS84 degrees) and dates; `config/scenarios.json` for the development layout (coordinates are fractions of the site box, so a layout works on any site). The notebook itself needs no edits.
- **What appears at the end:** the maps and tables shown below, a recommendation line, and the files in `results/`.

To fetch the sample input on its own: `python scripts/download_sample.py`.

## 8. Example input and output

**Input** (`data/sample_input/`, clipped to the site, about 0.6 MB in total):

| File | Content |
|---|---|
| `s2_reflectance.tif` | Sentinel-2 L2A red, NIR, SWIR-1 reflectance, 10 m, clouds masked |
| `landsat_lst_celsius.tif` | Landsat land surface temperature in degC, 30 m |
| `worldcover.tif` | ESA WorldCover 2021 classes, 10 m |
| `metadata.json` | Site, grid, scene IDs and dates |

**Output** (`results/`):

| File | Content |
|---|---|
| `example_output.png` / `scenario_comparison.png` | Layouts A and B, predicted LST change maps, and the four comparison metrics (top of this page) |
| `baseline_maps.png` | Existing site: false-colour image, NDVI, land cover, LST |
| `model_validation.png` | Spatial cross-validation and heat coefficients |
| `scenario_metrics.csv` | All metrics for today, A and B |
| `sensitivity.csv` | Ranking under 27 alternative assumptions |
| `greening_rule.csv` | Alternative B with 0%, 10% and 15% tree-planting rules |
| `run_summary.json` | Headline numbers and scene IDs |

![Existing site](results/baseline_maps.png)

## 9. Results and limitations

**Results on the Ras Al Khaimah site (11 June 2025):**

| Metric | Today | A: conventional | B: greener |
|---|---|---|---|
| Building footprint (ha) | 0 | 72.1 | 72.1 |
| Roads / paving (ha) | 0 | 9.9 | 5.5 |
| New tree planting (ha) | 0 | 0 | 10.8 (15% of building area) |
| Existing vegetation lost (ha) | 0 | **4.8** | **0.9** |
| Green cover of the 2.5 x 2.5 km site (%) | 4.2 | 3.4 | **5.7** |
| Mean daytime LST change in development zone (degC) | 0 | -2.30 | -2.45 |
| Area that gets more than 1 degC hotter (ha) | 0 | 0 | 0 |

- **Same building footprint, 82% less vegetation lost.** B keeps 3.9 ha of existing trees and farm plots that A paves over, and, with 10.8 ha of new trees (15% of the building area), leaves the site greener than today (5.7% vs. 4.2%), while A makes it less green (3.4%).
- **Daytime surface heat does not separate the designs on this site, and we report that as found.** At the Landsat overpass (about 10:30 local time) bare sand is the hottest surface in Digdaga, and the existing village is cooler than the open desert (built-up coefficient -4.2 degC). Replacing hot bare sand with buildings therefore lowers *daytime* LST in both designs; B is only 0.15 degC cooler than A, which is within the model error. The heat benefit of keeping vegetation is expected mostly in air temperature and at night, which a daytime Landsat scene cannot show (see limitations).
- **Heat model:** spatial cross-validation R2 = 0.53, mean absolute error 1.15 degC over 7,055 Landsat cells, LST range (p5-p95) 53.1-59.9 degC. Vegetation cools: -8.9 degC per unit NDVI.
- **Robustness:** across 27 combinations of assumptions, B is cooler than A in 27 of 27, and the vegetation result does not depend on the heat model at all.

![Model validation](results/model_validation.png)

**How we validated it**

- Spatial cross-validation of the heat model on held-out 300 m tiles (R2 and mean absolute error above).
- Physical sanity check: the NDVI coefficient must be negative (vegetation cools); the notebook warns if it is not.
- Sensitivity analysis over 27 assumption combinations (section 8 of the notebook).
- Visual check of the masks and land cover against the false-colour image.

**Where it breaks**

- **Surface, not air, temperature.** Landsat measures LST at about 10:30 local time. Air temperature, night-time heat and thermal comfort are not modelled.
- **Daytime only.** Landsat sees ~10:30 local time. In desert cities the night-time urban heat island is the bigger effect, and it is not captured yet.
- **One date.** Coefficients are calibrated on one summer scene; several dates would give a range.
- **Thermal resolution.** Landsat's thermal band is acquired at 100 m and delivered at 30 m. The 10 m maps show modelled change, not new thermal detail.
- **Linear, surface-only model.** Building height and shade, materials (albedo), irrigation, wind and anthropogenic heat are not represented.
- **Desert effect.** Sealing very hot bare sand lowers daytime LST, so a negative change does not mean "good". The linear model also treats a building on an irrigated farm plot as only slightly warmer than the farm, which likely understates the local heat cost of losing farmland. That is why vegetation lost is reported alongside heat.
- **New planting needs water.** Its cooling assumes it is irrigated and survives; water demand is not yet estimated.
- **Land cover from 2021.** Recent change may be missing from WorldCover; current vegetation comes from the Sentinel-2 scene itself.
- **Layouts are schematic.** Rectangles and road lines in fractional coordinates, not CAD or GIS plans (yet).
- **No hyperspectral data yet.** Next step: EnMAP / PRISMA to separate surface materials (asphalt, concrete, sand, irrigated vs. stressed vegetation) and estimate albedo, which the multispectral bands cannot do well.

## 10. Team, licence and attribution

| Member | Nationality | Specialisation | Project role |
|---|---|---|---|
| Yousef Al Suwaidi | UAE | - | Research and Documentation: site research in Ras Al Khaimah, documentation and presentation support |
| Maather Al Siyabi | Oman | Marketing and Business Administration | Marketing and Business Lead: target users, value proposition, business model |
| Fatema Al Ajmi | Oman | Aviation Management and Operations (minor in Business) | Team Leader, Operations and Coordination: leads the team, delivery, planning needs, process |
| Abdullah Khamis Al Araimi | Oman | Cybersecurity and Information Security | Cybersecurity Lead: secure data handling, no exposed credentials |
| Mariya Al Hasni | Oman | Networks and Data Security | Networks and Data Security Lead: data access, reproducibility, repository review |

**Code licence:** MIT (see `LICENSE`).

**Data attribution:** Contains modified Copernicus Sentinel data (2025). Landsat data courtesy of the U.S. Geological Survey. © ESA WorldCover project 2021 / Contains modified Copernicus Sentinel data (2021) processed by ESA WorldCover consortium (CC BY 4.0). Data accessed through the Microsoft Planetary Computer STAC API.

**Built on:** NumPy, pandas, SciPy, scikit-learn, rasterio / GDAL, pyproj, Shapely, GeoPandas, Matplotlib, pystac-client and planetary-computer.

## Repository layout

```
.
├── README.md
├── requirements.txt
├── LICENSE
├── config/
│   ├── site.json                 # site location and dates  <- edit
│   └── scenarios.json            # development layouts      <- edit
├── notebooks/
│   └── 02_main_analysis.ipynb    # the full PoC, runs end to end
├── data/sample_input/            # clipped satellite input + metadata.json
├── results/                      # figures and tables produced by the notebook
├── src/beforebuild/               # download, indices, heat model, scenarios, plots
├── scripts/
│   ├── download_sample.py        # fetch the sample input only
│   └── build_notebook.py         # developer helper that regenerates the notebook
└── docs/slides.pdf               # presentation
```
